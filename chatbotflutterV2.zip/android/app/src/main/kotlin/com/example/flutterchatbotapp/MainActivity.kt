package com.example.flutterchatbotapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
